<?php	
include_once('config.php');
require_once __DIR__ . '/auth_guard.php';
owner_require_auth($con);

$i=0;
   
    $response["invoiceResponse"] = array();
    mysqli_query($con, 'set names utf8');
    
    if ($_SERVER['REQUEST_METHOD'] == "GET") {
        
        $userId = $_GET['userId'];
$userId = owner_resolve_user_id($con, $userId);
if ($userId === null) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array('status'=>'0','message'=>'Unauthorized'));
    mysqli_close($con);
    exit;
}

        
        date_default_timezone_set("Asia/Calcutta");
        $date = date("Y-m-d");
        
	$sth="SELECT * FROM `invoice`
          LEFT JOIN `licenses` ON `licenses`.`id` = `invoice`.`licenseId`
          LEFT JOIN `users` ON `users`.`id` = `licenses`.`userId`
          WHERE `users`.`id` = '$userId' ORDER BY `invoiceId` DESC";

    if ($result = mysqli_query($con, $sth))
    {
        if (mysqli_num_rows($result) > 0)
        {
            
    while($row=mysqli_fetch_assoc($result))
    {
        $getdata = array();
       
        $getdata["invoiceId"]=$row['invoiceId'];
        $getdata["userId"]=$row['licenseId'];
        $getdata["noOfTable"]=$row['noOfTable'];
        $getdata["invoiceType"]=$row['invoiceType'];
        $getdata["invoiceNumber"]=$row['invoiceNumber'];
        $getdata["customerName"]=$row['customerName'];
        $getdata["customerMobile"]=$row['customerMobile'];
        $getdata["customerEmail"]=$row['customerEmail'];
        $getdata["customerAddress"]=$row['customerAddress'];
        $getdata["subTotal"]=$row['subTotal'];
        $getdata["totalGSTAmount"]=$row['totalGSTAmount'];
        $getdata["discount"]=$row['discount'];
        $getdata["discountType"]=$row['discountType'];
        $getdata["totalAmount"]=$row['totalAmount'];
        $getdata["paymentMode"]=$row['paymentMode'];
        $getdata["cashAmount"]=isset($row['cashAmount']) ? $row['cashAmount'] : '0';
        $getdata["upiAmount"]=isset($row['upiAmount']) ? $row['upiAmount'] : '0';
        $getdata["diningSessionId"]=isset($row['diningSessionId']) ? $row['diningSessionId'] : '';
        $getdata["billPrintStatus"]=isset($row['billPrintStatus']) ? $row['billPrintStatus'] : '';
        $getdata["packingCharge"]=isset($row['packingCharge']) ? $row['packingCharge'] : '0';
        $getdata["packingChargeType"]=isset($row['packingChargeType']) ? $row['packingChargeType'] : 'Percentage';
        $getdata["invoiceDate"]=$row['invoiceDate'];
        $getdata["invoiceOrderStatus"]=$row['invoiceOrderStatus'];
        $getdata["invoiceNetworkStatus"]=$row['invoiceNetworkStatus'];
        
        header('Content-type: application/json; charset=utf-8');
    
        array_push($response["invoiceResponse"], $getdata);
        }
            
        }
    }
    
    echo json_encode($response);
    }
?>