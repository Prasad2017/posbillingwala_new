<?php	
include_once('config.php');
require_once __DIR__ . '/pos_auth_guard.php';

$i=0;
   
    $response["inventoryResponse"] = array();
    mysqli_query($con, 'set names utf8');
    
    if ($_SERVER['REQUEST_METHOD'] == "GET") {
        
        $userId = $_GET['userId'];
        $__postedUserId = isset($_GET['userId']) ? $_GET['userId'] : (isset($userId) ? $userId : '');
        pos_require_auth($con, $__postedUserId, isset($response) ? $response : array('status'=>'0','message'=>'Unauthorized'));
        require_once __DIR__ . '/pos_staff.php';
        pos_require_permission($con, $userId, 'inventory.view');

        
        date_default_timezone_set("Asia/Calcutta");
        $date = date("Y-m-d");
        
	$sth="SELECT i.*, p.`productName` AS productName FROM `inventory` i"
            . " LEFT JOIN `products` p ON p.`productId` = i.`productId`"
            . " WHERE i.`userId`='$userId'";

    if ($result = mysqli_query($con, $sth))
    {
        if (mysqli_num_rows($result) > 0)
        {
            
    while($row=mysqli_fetch_assoc($result))
    {
        $getdata = array();
       
        $getdata["inventoryId"]=$row['inventoryId'];
        $getdata["productId"]=$row['productId'];
        $getdata["productName"]=isset($row['productName']) ? $row['productName'] : '';
        $getdata["productInventoryQuantity"]=$row['productInventoryQuantity'];
        $getdata["afterSaleInventoryQuantity"]=$row['afterSaleInventoryQuantity'];
        $getdata["saleInventoryQuantity"]=$row['saleInventoryQuantity'];
        $getdata["movementType"]=isset($row['movementType']) && $row['movementType'] !== '' ? $row['movementType'] : 'purchase';
        $getdata["inventoryNote"]=isset($row['inventoryNote']) ? $row['inventoryNote'] : '';
        $getdata["unitCost"]=isset($row['unitCost']) ? $row['unitCost'] : '0';
        $getdata["inventoryDate"]=$row['inventoryDate'];
        $getdata["inventoryNetworkStatus"]=$row['inventoryNetworkStatus'];
        $getdata["inventoryStatus"]=$row['inventoryStatus'];
       
        header('Content-type: application/json; charset=utf-8');
    
        array_push($response["inventoryResponse"], $getdata);
        }
            
        }
    }
    
    echo json_encode($response);
    }
?>