<?php
require_once __DIR__ . '/cors.php';
require_once __DIR__ . '/db_connection.php';
?>
