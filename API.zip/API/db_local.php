<?php
/**
 * Server/local DB credentials — gitignored. Do not commit.
 */
$dbHost = 'localhost';
$dbUser = 'rgusomuk_posbilling';
$dbPass = 'rgusomuk_posbilling';
$dbName = 'rgusomuk_posbilling';

$cronSecret = '9cd136440c1da8f18ddd6b308f97202885c2d4f601fdcf92db211202e249b74a';
// Require Bearer tokens on protected APIs. Leave false/unset so clients work without Authorization.
// $db_local = true;
// $requireAuthToken = true;
// Firebase HTTP v1 — private key from Console (pos-billingwala / firebase-adminsdk-fsuy5)
$fcmServiceAccountPath = __DIR__ . '/firebase-service-account.json';
$fcmProjectId = 'pos-billingwala';
// Web Push certificates (Firebase Console → Cloud Messaging → Web Push certificates).
// This is the PUBLIC VAPID key — only needed for browser FCM getToken({ vapidKey }).
// Android Admin/POS/Owner/Dealer push does NOT use this; it uses the service-account JSON above.
$fcmWebPushVapidKey = 'BN7K6l7Jn1-AsW6ZI6y5DonqslOzyZ2gkOHCDedIfFmHI2rTcUoJBdYMcWCnDgq3OdvKcVx3O3h_fARbWwRU-oU';

// Optional: absolute path to RSA private key for license payload signing.
// $licenseSigningPrivateKeyPath = '/secure/path/license_signing_private.pem';
