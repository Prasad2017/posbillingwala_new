<?php
/**
 * Server/local DB credentials — gitignored. Do not commit.
 */
$dbHost = 'localhost';
$dbUser = 'rgusomuk_posbilling';
$dbPass = 'rgusomuk_posbilling';
$dbName = 'rgusomuk_posbilling';

// Optional: absolute path to RSA private key for license payload signing.
// $licenseSigningPrivateKeyPath = '/secure/path/license_signing_private.pem';
