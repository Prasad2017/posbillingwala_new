<?php
include_once('config.php');
include_once('licence_expiry.php');
require_once __DIR__ . '/licence_payload.php';
require_once __DIR__ . '/pos_auth_guard.php';
require_once __DIR__ . '/pos_schema.php';
require_once __DIR__ . '/pos_devices.php';

mysqli_query($con, 'set names utf8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Authorization, Content-Type, Accept, X-Requested-With');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Content-Type: application/json');

$response = array('status' => '0', 'message' => 'Invalid request');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $licenceId = isset($_POST['userId']) ? trim($_POST['userId']) : '';
    $android_device_id = isset($_POST['android_device_id']) ? trim($_POST['android_device_id']) : '';

    if ($licenceId !== '' && $android_device_id !== '') {
        $check = db_stmt_fetch_one(
            $con,
            "SELECT `licenses`.*, `users`.`shopName`, `users`.`shopImage`, `users`.`reportPin`, `users`.`is_active` AS userActive
             FROM `licenses`
             LEFT JOIN `users` ON `users`.`id` = `licenses`.`userId`
             WHERE `licenses`.`id`=? AND `licenses`.`licenseStatus`='active'",
            's',
            $licenceId
        );

        if ($check !== null && licence_is_user_active(isset($check['userActive']) ? $check['userActive'] : null)
            && pos_device_authorized($con, $check, $android_device_id)) {
            $check = licence_sync_trial_consumed_state($con, $check);

            if (!licence_trial_allows_login($con, $check)) {
                $response['status'] = '0';
                $response['message'] = licence_trial_login_block_message($check);
            } elseif (!licence_enforce_expiry($con, $check)) {
                $response['status'] = '0';
                $response['message'] = 'Licence expired or user disabled';
            } else {
                $response['status'] = '1';
                $response['message'] = 'Key validate successfully.';
                $response['licenceId'] = $check['id'];
                $response['ownerId'] = $check['userId'];
                $response['userName'] = $check['userName'];
                $response['shopName'] = $check['shopName'];
                $response['shopImage'] = $check['shopImage'];
                $response['reportPin'] = $check['reportPin'];
                $response['fastBilling'] = $check['fastBilling'];
                $response['takeAway'] = $check['takeAway'];
                $response['dineIn'] = $check['dineIn'];
                $response['mess'] = $check['mess'];
                $response['licenceKey'] = $check['licenseKey'];
                $response['mpin'] = $check['mpin'];
                $response['licence_key_reg_date'] = $check['created_at'];
                $response['licence_key_expire_date'] = $check['expiryDate'];
                $response['totalSaleData'] = $check['total_sale_data'];
                $response['todaySaleData'] = $check['today_sale_data'];
                $response = licence_append_trial_response($con, $response, $check);
                $response = licence_append_user_management_response($con, $response, $check['id']);
                $response = licence_append_signed_payload($con, $response, $check, $android_device_id);
                auth_token_append_response($con, $response, 'pos_licence', $check['id'], $android_device_id, $check['expiryDate']);
                require_once __DIR__ . '/pos_presence.php';
                licence_touch_last_login($con, (int) $check['id']);
            }
        } else {
            $response['status'] = '0';
            $response['message'] = 'Licence expired, device mismatch, or user disabled';
        }
    } else {
        $response['message'] = 'Enter User Id and device id';
    }
} else {
    $response['message'] = 'Use Post Method';
}

mysqli_close($con);
echo json_encode($response);
?>
